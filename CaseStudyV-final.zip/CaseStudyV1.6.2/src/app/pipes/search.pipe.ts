import { Pipe, PipeTransform } from '@angular/core';
import { Restaurant } from '../models/restaurant';

@Pipe({
  name: 'search'
})
export class SearchPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    if( typeof args[0]==='undefined') return value
    
    return value.filter((restaurant) => {
     
      return restaurant.description.toUpperCase().indexOf(args[0].description.toUpperCase())> -1
    });
  }
}
