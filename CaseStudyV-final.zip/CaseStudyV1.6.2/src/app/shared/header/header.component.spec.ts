import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HeaderComponent } from './header.component';

describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;
  let el:HTMLElement
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    el = fixture.debugElement.nativeElement; // de.nativeElement;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should have h3 tag', () => {

    const content = el.querySelector('h3');
    expect(content.innerHTML).toContain('This is the header');
  });
});
