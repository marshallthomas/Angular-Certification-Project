import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { User } from 'src/app/models/user.model';

const apiUrl = 'http://localhost:3000/users';

@Injectable({
	providedIn: 'root'
})
export class FriendsService {
	constructor(private http: HttpClient) {}

	getUsers(): Observable<User[]> {
		console.log('Get All Users!');
		return this.http.get<User[]>(apiUrl);
	}

	getUserById(id): Observable<User> {
		return this.http.get<User>(apiUrl + '/' + id);
	}

	updateUser(data: User): Observable<any> {
		console.log('Update!');
		// Update works
		return this.http.put<User>(apiUrl + '/' + data.id, data);
	}
	deleteFriend(data: User): Observable<any> {
		console.log('Delete!');
		return this.http.put<User>(apiUrl + '/' + data.id, data);
	}
	addFriend(data: User): Observable<any> {
		return this.http.put<User>(apiUrl + '/' + data.id, data);
	}
}
