import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from 'src/app/models/user.model';

const apiUrl2 = 'http://localhost:3000/users'

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  user: User
 
  constructor(private http: HttpClient) { }

  getUserDetails(id): Observable<User>{
      return this.http.get<User>(apiUrl2 + '/' + id);
  }

}
