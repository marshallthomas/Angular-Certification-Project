import { Injectable } from '@angular/core';
import { Observable, empty } from 'rxjs'
import { User } from '../models/user.model';
import { HttpClient } from '@angular/common/http';
import { MsgService } from './msg.service';

const apiUrl = 'http://localhost:3000/users'
@Injectable({
  providedIn: 'root'
})
export class UserService {
  users: User[] = []
  id: number
  check: number=0;
  constructor(private http: HttpClient, private msgService: MsgService) { }
  login(creds: any): Observable <any> {
    const { username, password} = creds
    //TODO: API INTEGRATION ( POST Request)
    return new Observable ((observer) => {
      this.retrieveUsers().subscribe((data) =>{
        this.users=data;
        this.msgService.sendMsg({ msg: 'users gotten' })
      })
      this.retrieveUsers().subscribe((data) =>{
        this.users=data;
        this.msgService.sendMsg({ msg: 'users gotten' })
      })
      for(let item of this.users)
      {
        if(username === item.email && password ===item.password)
        {
          const user = {
            username,
            token: '',
            id: item.id,
          }
          if(username === 'admin')
          {
            user.token='admin'
          }
          else
          { 
            user.token='user'
          }
          localStorage.setItem('user', JSON.stringify(user))
          observer.next(user)
          this.check=1
        }
      }
      if(this.check===0){
        observer.error({ msg: 'Invalid Creds.' })

      }
      
    })
  }
  logout(){
    localStorage.removeItem('user')
    
  }
  getUserDetails(){
    return JSON.parse(localStorage.getItem('user'))

  }
  addUser(data): Observable<User> {
    if(data.profilePic==='no')
    {
      data.profilePic=null
    }
    data.orders = []
    data.friends = []
    return this.http.post<User>(apiUrl, data)
  }
  retrieveUsers(): Observable<User[]> {
    return this.http.get<User[]>(apiUrl)
  }
  deleteUser(id): Observable<any>{
    return this.http.delete(apiUrl + '/' + id)
  }
  resetPassword(datum): Observable<User>{
    this.retrieveUsers().subscribe((data) =>{
      this.users=data;
      this.msgService.sendMsg({ msg: 'users gotten' })
    })
    this.retrieveUsers().subscribe((data) =>{
      this.users=data;
      this.msgService.sendMsg({ msg: 'users gotten' })
    })
    this.id = 0
    for(let entry of this.users)
    {
      if(datum.email === entry.email)
      {
        this.id=entry.id
        datum.name=entry.name
        datum.profilePic=entry.profilePicture
        datum.orders=entry.orders
        datum.friends=entry.friends
        datum.phone=entry.phone
        datum.id=this.id
        break;
      }
    }
    if(this.id!==0){
      this.users=[]
      return this.http.put<User>(apiUrl + '/' + this.id, datum)
    }
    else{
      return empty();
    }
  }
}
