import { Injectable } from '@angular/core';
import { Observable} from 'rxjs';
import { HttpClient} from '@angular/common/http';
import { Restaurant} from 'src/app/models/restaurant';
import {User} from 'src/app/models/user.model'

const apiUrl= 'http://localhost:3000/restaurants'
const apiUrl2= 'http://localhost:3000/users'
@Injectable({
  providedIn: 'root'
})
export class RestaurantsService {

  constructor(private http: HttpClient ) { }

  getRestaurants(): Observable<Restaurant[]>  {
    return this.http.get<Restaurant[]>(apiUrl)
  }

  getSingleRestaurant(id): Observable<Restaurant>{
    return this.http.get<Restaurant>(apiUrl+'/'+id)
  }
  getSingleUser(id): Observable<User>{
    return this.http.get<User>(apiUrl2+'/'+id)
  }

  updateUserOrder(data): Observable<User>{
    console.log(data);
    return this.http.put<User>(apiUrl2+ '/' + data.id, data)
  }
}
