import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {

  constructor(public user: UserService, public router:Router) { }

  ngOnInit(): void {
  }
  handleLogout() {
    this.user.logout()
    this.router.navigate(['/'])
  }
  getUserDetails(){
    return this.user.getUserDetails()
  }
  handleProfile(){
    this.router.navigate(['/profile/'+ this.getUserDetails().id])
  }
}
