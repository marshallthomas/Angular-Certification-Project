import { Component, OnInit } from '@angular/core';

import { Validators, FormBuilder, FormGroup, Form } from '@angular/forms';
import { RegisterValidatorService } from 'src/app/services/register-validator.service'
import { UserService } from 'src/app/services/user.service';
import { MsgService } from 'src/app/services/msg.service';
import { User } from 'src/app/models/user.model'
import { Router } from '@angular/router';
@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  passwordForm: FormGroup;

  constructor(private msgService: MsgService,   
    private formValidator: RegisterValidatorService, 
    private builder: FormBuilder, 
    private userService: UserService,
    private router: Router) { }


  ngOnInit(): void {
    this.userService.resetPassword
    this.passwordForm = this.builder.group({
      email: ['', Validators.compose([Validators.required, Validators.email])],
      password: ['', Validators.required],
      confirmPassword: [''],
    }, {validators: this.formValidator.passwordsMatchValidator})
  }
  handleSubmit(){
    this.userService.resetPassword(this.passwordForm.value).subscribe(() => {
      this.msgService.getMsg()
      this.router.navigate(['/login'])
    })

  }

}
