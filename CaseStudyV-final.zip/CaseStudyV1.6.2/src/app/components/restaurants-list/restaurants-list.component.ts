import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {RestaurantsService} from 'src/app/services/restaurants.service';
import { Restaurant } from 'src/app/models/restaurant';

@Component({
  selector: 'app-restaurants-list',
  templateUrl: './restaurants-list.component.html',
  styleUrls: ['./restaurants-list.component.css']
})
export class RestaurantsListComponent implements OnInit {
 
  description: any = null;
  restaurants: Restaurant[]= []
  constructor(private route: ActivatedRoute,private restaurantService: RestaurantsService) { }

  ngOnInit(): void {
   this.description = this.route.snapshot.params;
   
    this.restaurantService.getRestaurants().subscribe((data: Restaurant[]) => {
      this.restaurants=data
    })
  }

}
