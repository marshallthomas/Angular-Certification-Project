import { Component, OnInit, ɵAPP_ID_RANDOM_PROVIDER } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import {RestaurantsService} from 'src/app/services/restaurants.service';
import { Restaurant } from 'src/app/models/restaurant';
import {User} from 'src/app/models/user.model';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-restaurant-details',
  templateUrl: './restaurant-details.component.html',
  styleUrls: ['./restaurant-details.component.css']
})
export class RestaurantDetailsComponent implements OnInit {
  restaurant: Restaurant=null;
  user: User=null;
  desc: any =null;
  constructor(private userService:UserService, private route: ActivatedRoute, private restaurantService: RestaurantsService, private router: Router) { }

  ngOnInit(): void {

    const { id }= this.route.snapshot.params;
    this.desc= this.route.snapshot.params;
    this.restaurantService.getSingleRestaurant(id).subscribe(data =>{
      this.restaurant=data;
    })

    
  }

  addOrder(id){
    this.restaurantService.getSingleUser(parseInt(this.userService.getUserDetails().id)).subscribe(data=>{
      //this.user=data;
      console.log(data)
      console.log(this.userService.getUserDetails().id)
     // console.log(data.orders);
      data.orders.push(id);
      console.log(data)
     // console.log(data.orders);
      this.restaurantService.updateUserOrder(data).subscribe();
    })
    
  }
  handleBack(){
    const {desc} = this.route.snapshot.params;
   // console.log(desc);
   this.router.navigate(['/homepage',desc])
  }
}
