import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { Router } from '@angular/router';
import { RegisterValidatorService } from 'src/app/services/register-validator.service';
import { Form, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { User } from 'src/app/models/user.model';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  model: any = {}
  users: User[] = []
  constructor(
    private user: UserService,
    private router: Router, 
    ) { }

  ngOnInit(): void {
    this.model.username="a"
    this.model.password="a"
    this.user.login(this.model).subscribe((data) =>{
      
    }, (err) =>{

    })
    this.model={}
  }
  handleSubmit(){
    this.user.login(this.model).subscribe((data) =>{
      this.router.navigate(['/homepage'])
    }, (err)=>{
      console.log(err)
    })
  }

}
