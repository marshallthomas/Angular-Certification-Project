import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup, Form } from '@angular/forms';
import { RegisterValidatorService } from 'src/app/services/register-validator.service'
import { UserService } from 'src/app/services/user.service'
import { User } from 'src/app/models/user.model'
import { MsgService } from 'src/app/services/msg.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registerForm: FormGroup;
  user: User
  constructor(private msgService: MsgService, 
    private builder: FormBuilder, 
    private formValidator: RegisterValidatorService, 
    private userService: UserService,
    private router: Router,) { }
  
  ngOnInit(): void {
    this.registerForm = this.builder.group({
      name: ['', Validators.required],
      email: ['', Validators.compose([Validators.required, Validators.email])],
      phone: ['', Validators.compose([Validators.required, Validators.pattern("[0-9]*"), Validators.minLength(10)])],
      password: ['', Validators.required],
      confirmPassword: [''],
  
    }, {validators: this.formValidator.passwordsMatchValidator})
  }
  
    handleSubmit() {
      const data = {
        name: this.registerForm.value.name,
        phone: this.registerForm.value.phone,
        email: this.registerForm.value.email,
        password: this.registerForm.value.password,
        profilePicture: "assets/blank.jpg"

      }
      this.userService.addUser(data).subscribe(() => {
        this.msgService.sendMsg({ msg: 'User Added!' })
        
        this.router.navigate(['/login'])
      })
    }

}
