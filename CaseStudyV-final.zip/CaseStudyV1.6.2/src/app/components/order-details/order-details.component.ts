import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import {RestaurantsService} from 'src/app/services/restaurants.service';
import { Restaurant } from 'src/app/models/restaurant';
import { UserService } from 'src/app/services/user.service';
import { User } from 'src/app/models/user.model';
import { OrderService } from 'src/app/services/order.service';


@Component({
  selector: 'app-order-details',
  templateUrl: './order-details.component.html',
  styleUrls: ['./order-details.component.css']
})
export class OrderDetailsComponent implements OnInit {

  user: User;
  orders: number[] = []
  restaurant: Restaurant[] = []
  id: number


  constructor(public userService: UserService, private route: ActivatedRoute, private restaurantService: RestaurantsService, private router: Router, private orderService: OrderService) { }

  ngOnInit(): void {
    this.user = this.userService.getUserDetails()
    console.log(this.user)

    this.id = this.user.id
    this.orderService.getUserDetails(this.id).subscribe(data => {
      //console.log(data.orders)
      this.orders = data.orders;

        for(var i=0;i<this.orders.length;i++){
              this.restaurantService.getSingleRestaurant(this.orders[i]).subscribe(data => {

                this.restaurant.push(data)
               }) ;
      }
    });

    
console.log(this.restaurant)
  

    }

    

  



}
