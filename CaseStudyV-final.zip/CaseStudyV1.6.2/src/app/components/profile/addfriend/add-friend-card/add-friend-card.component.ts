import { Component, OnInit, Input } from '@angular/core';
import { User } from 'src/app/models/user.model';
import { FriendsService } from 'src/app/services/friends.service';
import { MsgService } from 'src/app/services/msg.service';
@Component({
	selector: 'app-add-friend-card',
	templateUrl: './add-friend-card.component.html',
	styleUrls: [ './add-friend-card.component.css' ]
})
export class AddFriendCardComponent implements OnInit {
	@Input() user: User;
	@Input() currentUser: User;
	constructor(private friendService: FriendsService, private msgService: MsgService) {}

	ngOnInit(): void {}
	friendsList(u: User): number {
		return u.friends.length;
	}
	handleAddFriend() {
		this.currentUser.friends.push(this.user.id);
		console.log(this.currentUser)
		this.friendService.addFriend(this.currentUser).subscribe(() => {
			this.msgService.sendMsg({ msg: 'Friend Added!' });
			console.log(this.currentUser);
		});
	}
}
