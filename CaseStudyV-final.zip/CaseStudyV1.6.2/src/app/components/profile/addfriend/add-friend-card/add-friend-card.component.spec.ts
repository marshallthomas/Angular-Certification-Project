import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddFriendCardComponent } from './add-friend-card.component';

describe('AddFriendCardComponent', () => {
  let component: AddFriendCardComponent;
  let fixture: ComponentFixture<AddFriendCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddFriendCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddFriendCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
