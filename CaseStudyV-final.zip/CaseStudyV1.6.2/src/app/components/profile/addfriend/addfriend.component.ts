import { Component, OnInit } from '@angular/core';
import { FriendsService } from 'src/app/services/friends.service';

import { User } from 'src/app/models/user.model';
import { async } from 'rxjs/internal/scheduler/async';
import { MsgService } from 'src/app/services/msg.service';
@Component({
	selector: 'app-addfriend',
	templateUrl: './addfriend.component.html',
	styleUrls: [ './addfriend.component.css' ]
})
export class AddfriendComponent implements OnInit {
	currentUser: User;
	currentUserFirendsList: User[] = [];
	avaliableFriends: User[] = [];
	userList: User[] = [];

	constructor(private friendService: FriendsService, private msgService: MsgService) {}

	ngOnInit(): void {
		this.makeFutureFriendsList()
		this.msgService.getMsg().subscribe(() => {
			this.makeFutureFriendsList();
		});
	}
	makeFutureFriendsList(){
		this.avaliableFriends = []
		this.currentUser = JSON.parse(localStorage.getItem('user'));
		console.table(this.currentUser);
		this.friendService.getUserById(this.currentUser.id).subscribe((data: User) => {
			this.currentUser = data;

			this.friendService.getUsers().subscribe((allusers: User[]) => {
				this.userList = allusers;

				for (let i = 0; i < this.userList.length; i++) {
					if (
						this.currentUser.id !== this.userList[i].id &&
						!this.currentUser.friends.includes(this.userList[i].id)
					) {
						this.avaliableFriends.push(this.userList[i]);
					}
				}
			});
		});
	}
}
