import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditProfileMenuComponent } from './edit-profile-menu.component';

describe('EditProfileMenuComponent', () => {
  let component: EditProfileMenuComponent;
  let fixture: ComponentFixture<EditProfileMenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditProfileMenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditProfileMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
