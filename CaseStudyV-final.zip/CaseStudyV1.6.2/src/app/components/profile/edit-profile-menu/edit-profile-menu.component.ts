import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FriendsService } from 'src/app/services/friends.service';

import { User } from 'src/app/models/user.model';
@Component({
  selector: 'app-edit-profile-menu',
  templateUrl: './edit-profile-menu.component.html',
  styleUrls: ['./edit-profile-menu.component.css'],
})
export class EditProfileMenuComponent implements OnInit {
  constructor(
    private route: ActivatedRoute,
    private firendService: FriendsService
  ) {}
  currentUser: User = null;
  ngOnInit(): void {
    //this.currentUser = JSON.parse(localStorage.getItem('user'));
    const { id } = this.route.snapshot.params;
    this.firendService.getUserById(id).subscribe((data: User) => {
      this.currentUser = data;
    });
  }
  handleAdd(){
    
  }
}
