import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FriendsService } from 'src/app/services/friends.service';
import { User } from 'src/app/models/user.model';
import { MsgService } from 'src/app/services/msg.service';
@Component({
	selector: 'app-friend-card',
	templateUrl: './friend-card.component.html',
	styleUrls: [ './friend-card.component.css' ]
})
export class FriendCardComponent implements OnInit {
	@Input() user: User;
	currentUser: User = null;
	constructor(
		private friendService: FriendsService,
		private route: ActivatedRoute,
		private router: Router,
		private msgService: MsgService
	) {}

	ngOnInit(): void {
		const { id } = this.route.snapshot.params;
		this.friendService.getUserById(id).subscribe((data: User) => {
			this.currentUser = data;
			// console.table(this.currentUser);
		});
	}

	friendsList(u: User): number {
		return u.friends.length;
	}
	handleDelete() {
		let templist: User = this.currentUser;

		for (let i = 0; i < templist.friends.length; i++) {
			console.log(templist.friends[i]);
			if (templist.friends[i] === this.user.id) {
				templist.friends.splice(i, 1);
				this.friendService.deleteFriend(templist).subscribe(() => {
					this.msgService.sendMsg({ msg: 'friend deleted' });
					console.log(this.router.url);
				});
			}
		}

		//  this.friendService.deleteFriend();
	}
}
