import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FriendsService } from 'src/app/services/friends.service';

import { FormGroup, FormBuilder, Validators } from '@angular/forms';

import { User } from 'src/app/models/user.model';
import { MsgService } from 'src/app/services/msg.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css'],
})
export class ProfileComponent implements OnInit {
  constructor(
    private route: ActivatedRoute,
    private friendService: FriendsService,
    private builder: FormBuilder,
    private msgService: MsgService
  ) {}

  currentUser: User = null;
  editUser = false;
  editUserForm: FormGroup;

  ngOnInit(): void {
    const { id } = this.route.snapshot.params;
    this.friendService.getUserById(id).subscribe((data: User) => {
      this.currentUser = data;
    });

    this.editUserForm = this.builder.group({
      // email: ['', Validators.email],
      // phone: ['', Validators.minLength(10)],
      name: '',
      email: ['', Validators.email],
      phone: '',
    });
  }

  editProfile() {
    this.editUser = true;
    //   this.nameInput.nativeElement.value = 'howdy';
    //  console.log(this.nameInput.nativeElement.textContent);
    this.editUserForm.setValue({
      name: this.currentUser.name,
      email: this.currentUser.email,
      phone: this.currentUser.phone,
    });
  }

  handleSubmit() {
    let tempUser = null;
    this.friendService
      .getUserById(this.currentUser.id)
      .subscribe((data: User) => {
        tempUser = data;
        const { name, email, phone } = this.editUserForm.value;

        if (name !== '') tempUser.name = name;
        if (email !== '') tempUser.email = email;
        if (phone !== '') tempUser.phone = phone;
        this.friendService.updateUser(tempUser).subscribe();
      });
    this.editUser = false;
  }
  handleAdd(){
    this.currentUser.friends.push(1);
    this.friendService.addFriend(this.currentUser).subscribe(() => {
      this.msgService.sendMsg({msg: 'Friend Added'})
  })
  }
  defaultFormValues() {}
}
