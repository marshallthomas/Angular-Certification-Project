import { Component, OnInit, Input } from '@angular/core';
import { Restaurant } from 'src/app/models/restaurant';
import {Router} from '@angular/router';

@Component({
  selector: 'app-restaurant-item',
  templateUrl: './restaurant-item.component.html',
  styleUrls: ['./restaurant-item.component.css']
})
export class RestaurantItemComponent implements OnInit {

  @Input() restaurant: Restaurant;
  @Input() descrip: any;
  constructor(public router: Router) { }

  ngOnInit(): void {
   
  }

  handleNavigate(){
   
    this.router.navigate(['/restaurant',this.restaurant.id,this.descrip.description])
  }
}
//[routerLink]="['/restaurant',{id:restaurant.id,desc:descrip.description}]"
//this.router.navigate(['/myUrlPath', "someId", "another ID"]);