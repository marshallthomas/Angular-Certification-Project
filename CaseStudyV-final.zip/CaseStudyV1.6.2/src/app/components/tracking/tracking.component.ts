import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tracking',
  templateUrl: './tracking.component.html',
  styleUrls: ['./tracking.component.css']
})
export class TrackingComponent implements OnInit {

  orderNo: number = 10;
  placed: boolean = true;
  pickedUp: boolean = true;
  delivered : boolean = false;
  status: string  = "Picked Up";

  constructor() { }

  ngOnInit(): void {
  }

}
