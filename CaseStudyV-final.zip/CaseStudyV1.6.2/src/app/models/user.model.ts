export class User {
    id: number;
    name: string;
    phone: string;
    email: string;
    friends: number[]
    orders: number[]
    password: string;
    profilePicture: string;
  
    constructor(id, name, phone, email, friends=[], orders=[], password, profilePicture) {
      this.id = id
      this.name=name
      this.email=email
      this.phone=phone
      this.password = password
      this.profilePicture = profilePicture
      this.orders=orders
      this.friends=friends

    }
}
