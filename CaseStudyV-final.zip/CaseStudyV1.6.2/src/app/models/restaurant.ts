export class Restaurant {
    id: number
    createdAt: string
    updatedAt: string
    restaurent_name: string
    rating: number
    description: string
    name: string
    image_url: string
    cost: number
    //zip: number

    constructor(id,createdAt,updatedAt,restaurent_name,rating,description,name,image_url,cost){
        this.id = id;
        this.createdAt=createdAt;
        this.updatedAt=updatedAt;
        this.restaurent_name=restaurent_name;
        this.description=description;
        this.name=name;
        this.image_url = image_url;
        this.rating = rating;
        this.cost=cost;
      //  this.zip = zip;    
    }
}
