import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { Routes, RouterModule } from '@angular/router'
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { HttpClientModule } from '@angular/common/http';
import { NavComponent } from './components/nav/nav.component'
import { AuthGuard} from './guards/auth.guard';
import { AdminGuard } from './guards/admin.guard'
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component'
import { FeedComponent } from './shared/feed/feed.component';
import { RestaurantDetailsComponent } from './components/restaurant-details/restaurant-details.component';
import { RestaurantItemComponent } from './components/restaurant-item/restaurant-item.component';
import { RestaurantsListComponent } from './components/restaurants-list/restaurants-list.component';
import { HomepageComponent } from './components/homepage/homepage.component';
import { SearchPipe } from './pipes/search.pipe';
import { EditProfileMenuComponent } from './components/profile/edit-profile-menu/edit-profile-menu.component';
import { ProfileComponent } from './components/profile/profile.component';
import { FriendlistComponent } from './components/profile/friendlist/friendlist.component';
import { FriendCardComponent } from './components/profile/friendlist/friend-card/friend-card.component';
import { OrderDetailsComponent } from './components/order-details/order-details.component';
import { TrackingComponent } from './components/tracking/tracking.component';
import { AddfriendComponent } from './components/profile/addfriend/addfriend.component';
import { AddFriendCardComponent } from './components/profile/addfriend/add-friend-card/add-friend-card.component';
const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'register', component: RegisterComponent},
  { path: 'login', component: LoginComponent},
  { path: 'reset', component: ForgotPasswordComponent},
  { path: 'feed', component: FeedComponent, canActivate: [AdminGuard]},
  { path: 'homepage', component: HomepageComponent},
  { path: 'homepage/:description', component: RestaurantsListComponent},
  { path: 'restaurant/:id/:desc', component: RestaurantDetailsComponent, canActivate: [AuthGuard]},
  { path: 'profile/:id', component: ProfileComponent, canActivate: [AuthGuard]},
  { path: 'order', component: OrderDetailsComponent, canActivate: [AuthGuard]},
  { path: 'order/tracking', component: TrackingComponent, canActivate: [AuthGuard]},
  { path: 'profile/friendlist/:id', component: FriendlistComponent, canActivate: [AuthGuard]},
  { path: 'profile/addfriend/:id', component: AddfriendComponent, canActivate: [AuthGuard]},
]


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    NavComponent,
    ForgotPasswordComponent,
    RestaurantDetailsComponent,
    RestaurantItemComponent,
    RestaurantsListComponent,
    HomepageComponent,
    SearchPipe,
    EditProfileMenuComponent,
    ProfileComponent,
    FriendlistComponent,
    FriendCardComponent,
    OrderDetailsComponent,
    TrackingComponent,
    AddfriendComponent,
    AddFriendCardComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
